	/* Se agrega en la línea 33:
		changeRandomDirection(){
			this.randomTargetIndex += parseInt(Math.random() * 4);
			this.randomTargetIndex = this.randomTargetIndex % 4;
		}
	*/

	draw() {
		canvasContext.save();
		canvasContext.drawImage(
			ghotsFrames,
			this.imageX,
			this.imageY,
			this.imageWidth,
			this.imageHeight,
			this.x,
			this.y,
			this.width,
			this.height
		);
		canvasContext.restore();

		canvasContext.beginPath();
		canvasContext.strokeStyle = "red";
		canvasContext.arc(
			this.x + oneBlockSize / 2,
			this.y + oneBlockSize / 2,
			this.range * oneBlockSize,
			0,
			2 * Math.PI
		);
		canvasContext.stroke();
	}