	/* Se agrega en la línea 20 y 21:
		let lives = 3;
		let foodCount = 0;
	*/

	/*
		Se agrega en la línea 146:
			drawLives();
	*/

	let update = () => {
		pacman.moveProcess();
		pacma.eat();
		for (let i = 0; i < ghosts.length; i++) {
			ghosts[i].moveProcess();
		}

		if (pacman.checkGhostCollision()) {
			console.log("hit");
			restartGame();
		}
		if ( score >= foodCount) {
			drawWin();
			clearInterval(gameInterval);
		}
	};

	let restartGame = () => {
		createNewPacman();
		createGhosts();
		lives--;
		if (lives == 0) {
			gameOver();
		}
	};

	let gameOver = () => {
		drawGameOver()
		clearInterval(gameInterval);
	};

	let drawGameOver = () => {
		canvasContext.font = "20px Emulogic";
		canvasContext.fillStyle = "white";
		canvasContext.fillText ("Fin del Juego!", 150, 200);
	};

	let drawWin = () => {
		canvasContext.font = "20px Emulogic";
		canvasContext.fillStyle = "white";
		canvasContext.fillText ("Ganaste! Ganaste!", 150, 200);
	};

	let drawLives = () => {
		canvasContext.font = "20px Emulogic";
		canvasContext.fillStyle = "white";
		canvasContext.fillText (
			"Lives: ", 
			220, 
			oneBlockSize * (map.length + 1) + 10
		);
		for (let i = 0; i < lives; i++) {
			canvasContext.drawImage(
				pacmanFrames,
				2 * oneBlockSize,
				0,
				oneBlockSize,
				oneBlockSize,
				350 + i * oneBlockSize,
				oneBlockSize * map.length + 10,
				oneBlockSize,
				oneBlockSize
			);
		}
	};